#pragma once

// This project made by Asaf Zafrir (205929029)

//---        Enumerable.h          ---//

enum Element {
	Uninitialized, // not possiable.
	Ameno,
	Pyro,
	Cyro,
	Hydro,
	Electro,
	Geo,
	Dendro
};

enum Weapon {
	unarmed, // not possiable.
	Sword,
	Polearm,
	Catalyst,
	Claymore,
	Bow
};